package mainpage;

import java.awt.Desktop.Action;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import mainbase.Basics;

public class Pagevalues extends Basics {
	WebDriver driver;
	Actions act;
	WebDriverWait wait;
	
	@FindBy(xpath= "//*[@id=\"view\"]/div[1]/header/a")
	WebElement logo;
	@FindBy(xpath = "//*[@id=\"view\"]/div[1]/header/div/ul[3]/li/div/button")
	WebElement loginicon;
	@FindBy( id = "email")
	WebElement loginemail;
	@FindBy( xpath = "//*[@id=\"password\"]")
	WebElement loginpass;
	@FindBy(xpath ="//*[@id=\"login-form\"]/div[4]/button")
	WebElement loginbutton;
	@FindBy(xpath = "/html/body/div[3]/div/div/div[1]/button")
	WebElement loginclose;
	@FindBy(xpath ="//*[@id=\"view\"]/div[1]/div/nav/ul/li[2]/a")
	WebElement car;
	@FindBy(xpath ="//*[@id=\"view\"]/div[1]/div/nav/ul/li[11]/a")
	WebElement astonmartin;
@FindBy(xpath ="//*[@id=\"view\"]/div[1]/div/div[2]/select")
WebElement dropdown;
@FindBy(xpath = "//*[@id=\"view\"]/div[1]/div/button[2]")
WebElement year;
@FindBy(xpath ="/html/body/div[1]/div[1]/div/button[2]")
WebElement minyear;
@FindBy(xpath="//*[@id=\"year_to\"]")
WebElement maxyear;
@FindBy(xpath="//*[@id=\"page_content\"]/section/div[1]/div[2]/div/div[1]/a/div[2]/div/div[1]")
WebElement carv;



public Pagevalues(WebDriver driver) {
	this.driver = driver;
	this.act = new Actions(driver);

	
	this.wait = new WebDriverWait(driver,Duration.ofSeconds(30));
	PageFactory.initElements(driver, this);
}
	public void title() {
		String exptitle = "The World's Luxury Marketplace: Homes, Cars, Yachts & Jets for Sale | JamesEdition";
		String act = driver.getTitle();
		System.out.println(act);
		Assert.assertEquals(exptitle, act);
	}
	public void logoverification() {
		boolean logopresent = logo.isDisplayed();
		Assert.assertTrue(logopresent,"logo needs to present");
	}
	public void loginicon()  {
		loginicon.click();
	
		
	}
	public void loginemail() throws Exception {
		Thread.sleep(4000);
		loginemail.click();
	}
	public void setvalues(String usr,String pass) {
	loginemail.clear();
	loginemail.sendKeys(usr);
	loginpass.clear();
	loginpass.sendKeys(pass);
		
	}
public void loginbutton() throws InterruptedException  {
	Thread.sleep(5000);
	loginbutton.click();

	
}
//
//public void loginclosebutton() throws Exception {
//	Thread.sleep(3000);
//	loginclose.click();
//
//}
public void backhome() throws InterruptedException {
	Thread.sleep(3000);
	driver.navigate().to("https://www.jamesedition.com/");
}
public void carboking() {
	car.click();
}
public void carselect() {
	astonmartin.click();
}
//public void dropdown() throws InterruptedException {
//	dropdown.click();
//	Select drop = new Select (dropdown);
//	drop.selectByVisibleText("vantage");
//}
public void datepick() {
	year.click();
	wait.until(ExpectedConditions.elementToBeClickable(minyear)).click();
	WebElement opt = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"year_from\"]/option[28]")));
	opt.click();
	wait.until(ExpectedConditions.elementToBeClickable(maxyear)).click();
	WebElement opt1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"year_to\"]/option[22]")));
	opt1.click();
	
}
public void v() throws IOException {
	wait.until(ExpectedConditions.visibilityOf(carv));
	act.moveToElement(carv);
	act.moveToElement(carv).click();
	act.perform();

	String parent = driver.getWindowHandle();
for(String handle : driver.getWindowHandles()) {
	if(!handle.equals(parent)) {
		driver.switchTo().window(handle);
		break;
	}
	
}
Basics.capturescreenshot(parent);

	}



}


