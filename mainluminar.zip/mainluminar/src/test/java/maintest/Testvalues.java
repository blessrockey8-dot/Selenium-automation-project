package maintest;

import org.testng.annotations.Test;

import mainbase.Basics;
import mainpage.Pagevalues;
import testutilitys.Utilityvalue;

public class Testvalues extends Basics {
	@Test
	public void testing() throws Exception {
		Pagevalues ob = new Pagevalues(driver);
		ob.title();
		ob.logoverification();
		ob.loginicon();
		ob.loginemail();
		String xl = "D:\\luminar\\server1.xlsx";
				String sheet = "sheet1";
		int rowcount = Utilityvalue.getRowCount(xl, sheet);
		for (int i = 1;i<=rowcount;i++) {
			String username = Utilityvalue.getcellvalues(xl, sheet, i, 0);
			System.out.println(username);
			String password = Utilityvalue.getcellvalues(xl, sheet, i, 1);
			System.out.println(password);
			ob.setvalues(username, password);
			ob.loginbutton();
			
		}
	ob.backhome();
	ob.carboking();
	ob.carselect();
//	ob.dropdown();
	ob.datepick();
	ob.v();
	
	
	}
	

}
