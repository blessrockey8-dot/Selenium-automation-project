package mainbase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;



	import java.io.File;
	import java.io.IOException;
	import java.lang.reflect.Method;
	import java.time.Duration;

	import org.apache.commons.io.FileUtils;
	import org.openqa.selenium.OutputType;
	import org.openqa.selenium.TakesScreenshot;
	import org.testng.ITestResult;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.AfterTest;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.BeforeTest;

	import com.aventstack.extentreports.ExtentReports;
	import com.aventstack.extentreports.ExtentTest;
	import com.aventstack.extentreports.Status;
	import com.aventstack.extentreports.reporter.ExtentSparkReporter;
	import com.aventstack.extentreports.reporter.configuration.Theme;

	public class Basics {
	 ExtentSparkReporter reporter;
	 public static ExtentTest test;
	 public ExtentReports extent;
	 String baseUrl="https://www.jamesedition.com/";
	 public static WebDriver driver;
	 @BeforeTest
	 public void ExtentReports() {
	  reporter=new ExtentSparkReporter("./Reports/myreport1.html");
	  reporter.config().setDocumentTitle("Automation report");
	  reporter.config().setReportName("Functional test");
	  reporter.config().setTheme(Theme.DARK);
	  extent=new ExtentReports();
	  extent.attachReporter(reporter);
	  extent.setSystemInfo("Host Name", "My Host");
	  extent.setSystemInfo("OS", "Window10");
	  extent.setSystemInfo("Tester Name", "KILLUA");
	  extent.setSystemInfo("Browser Name", "chrome");
	 }
	 @BeforeClass
	 public void setUp() {
	  driver=new ChromeDriver();
	  driver.get(baseUrl);
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	 }
	 
	 @BeforeMethod
	 public void startTest(Method method)
	 {
	  test = extent.createTest(method.getName());
	 }

	 @AfterMethod
	 public void browserClose(ITestResult result) throws IOException {
	  if(result.getStatus()==ITestResult.FAILURE)
	  {
	   test.log(Status.FAIL, "Test Case failed : "+result.getName());
	   test.log(Status.FAIL, "Reason : "+result.getThrowable());
	  //Take screenshot
	  String screenShotPath=capturescreenshot(result.getName());
	  //Attach screenshot to Extent Report
	  test.addScreenCaptureFromPath(screenShotPath);
	  }
	  else if(result.getStatus()==ITestResult.SKIP)
	  {
	   test.log(Status.SKIP, "Test Case Skipped : "+result.getName());
	  }
	  else if(result.getStatus()==ITestResult.SUCCESS)
	  {
	   test.log(Status.PASS, "Test Case Passed : "+result.getName());
	  }
	 }
	 public static String capturescreenshot(String screenshotName) throws IOException {
	  File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	  String path = System.getProperty("user.dir") + "/screenshots/" + screenshotName + ".png";
	  File dest=new File(path);
	  FileUtils.copyFile(src, dest);
	  test.addScreenCaptureFromPath(path);
 
	  return path;
	 }
	 
	 @AfterTest
	 public void tearDown() {
	  driver.quit();
	  extent.flush();
	 }


	}



